# **App Name**: GuiaWeb Dev

## Core Features:

- Tutorial HTML: Apresentar um passo a passo do HTML básico.
- Tutorial CSS: Apresentar um passo a passo do CSS básico.
- Tutorial JavaScript: Apresentar um passo a passo do JavaScript básico.
- Integração: Apresentar um guia de como juntar HTML, CSS e JavaScript para criar uma página web.
- Links extras: Possuir links para conteúdos extras sobre o conteúdo ensinado.
- Assistente IA de Código: Disponibilizar ferramenta de IA para ajudar na criação dos primeiros códigos de marcação, auxiliando o aluno com snippets prontos de código.

## Style Guidelines:

- Cor primária: Azul suave (#77B5FE), representando aprendizado e confiança.
- Cor de fundo: Branco acinzentado claro (#F5F5F5), para facilitar a leitura e reduzir o cansaço visual.
- Cor de destaque: Laranja vibrante (#FF8A5B), usada em botões e chamadas para ação.
- Fonte para títulos e corpo do texto: 'PT Sans', uma fonte sans-serif humanista moderna.
- Fonte para snippets de código: 'Source Code Pro', uma fonte monospace para fácil leitura.
- Ícones simples e diretos, focados em usabilidade e fácil identificação dos tópicos.
- Animações leves ao navegar entre os tópicos e ao exibir o resultado dos exercícios práticos.