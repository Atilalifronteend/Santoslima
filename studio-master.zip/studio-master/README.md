# Programar é Ganhar Dinheiro - Guia de Desenvolvimento Web

Bem-vindo ao "Programar é Ganhar Dinheiro"! Este é um projeto educacional construído com Next.js, projetado para ajudar iniciantes a aprender os fundamentos do desenvolvimento web, incluindo HTML, CSS, JavaScript e conceitos mais avançados, além de uma introdução ao uso de IA para geração de código.

## Tecnologias Utilizadas

*   **Next.js (App Router):** Framework React para renderização no servidor e geração de sites estáticos.
*   **React:** Biblioteca JavaScript para construir interfaces de usuário.
*   **TypeScript:** Superset do JavaScript que adiciona tipagem estática.
*   **ShadCN UI:** Coleção de componentes de UI reutilizáveis.
*   **Tailwind CSS:** Framework CSS utility-first para estilização rápida.
*   **Genkit (Firebase AI):** Para funcionalidades de IA, como o assistente de geração de código.
*   **Lucide Icons:** Biblioteca de ícones.

## Começando

Para executar este projeto localmente, siga os passos abaixo:

1.  **Clone o Repositório:**
    Se você estiver acessando este projeto a partir do GitHub, clone-o para sua máquina local. **Certifique-se de substituir `URL_DO_SEU_REPOSITORIO_NO_GITHUB.git` pelo URL real do seu repositório!**
    ```bash
    git clone URL_DO_SEU_REPOSITORIO_NO_GITHUB.git
    cd NOME_DA_PASTA_DO_PROJETO 
    ```
    (Substitua `NOME_DA_PASTA_DO_PROJETO` pelo nome da pasta que será criada).

    Se você baixou o projeto como um arquivo ZIP do Firebase Studio ou de outra fonte, descompacte-o e navegue até a pasta raiz do projeto no seu terminal.

2.  **Instale as Dependências:**
    Com o Node.js e npm (ou yarn) instalados, execute o seguinte comando na pasta raiz do projeto para instalar todas as dependências necessárias:
    ```bash
    npm install
    ```
    ou se você usa yarn:
    ```bash
    yarn install
    ```

3.  **Configure as Variáveis de Ambiente (se necessário):**
    Este projeto pode requerer variáveis de ambiente para funcionalidades de IA (Genkit/Google AI), como uma `GOOGLE_API_KEY`.
    *   Copie o arquivo `.env.example` (se existir) para `.env`.
    *   Preencha os valores necessários no arquivo `.env`. Atualmente, o arquivo `.env` está vazio, mas é uma boa prática estar ciente disso para futuras integrações de API ou para configurar chaves de IA.
    *   O arquivo `src/ai/dev.ts` utiliza `dotenv` para carregar essas variáveis.

4.  **Execute o Servidor de Desenvolvimento Next.js:**
    Para iniciar a aplicação web principal:
    ```bash
    npm run dev
    ```
    Isso geralmente iniciará o aplicativo em `http://localhost:9002` (conforme configurado em `package.json`). Abra este endereço no seu navegador.

5.  **Execute o Servidor de Desenvolvimento Genkit (Opcional - para funcionalidades de IA):**
    Se você for desenvolver ou testar as funcionalidades de IA (como o assistente de código):
    *   Para iniciar o servidor Genkit:
        ```bash
        npm run genkit:dev
        ```
    *   Para iniciar o servidor Genkit com recarregamento automático ao modificar arquivos de IA:
        ```bash
        npm run genkit:watch
        ```
    O servidor Genkit normalmente é executado em uma porta diferente (padrão: 4000) e permite que o Next.js se comunique com os fluxos de IA.

## Estrutura do Projeto (Visão Geral)

*   `src/app/`: Contém as rotas principais e páginas da aplicação (usando o Next.js App Router).
*   `src/components/`: Componentes React reutilizáveis (incluindo componentes UI da ShadCN).
*   `src/ai/`: Lógica relacionada à IA, incluindo fluxos Genkit.
    *   `src/ai/flows/`: Define os fluxos de IA (ex: `generate-code-snippet.ts`).
    *   `src/ai/genkit.ts`: Configuração do cliente Genkit.
    *   `src/ai/dev.ts`: Ponto de entrada para o servidor de desenvolvimento Genkit.
*   `public/`: Arquivos estáticos.
*   `package.json`: Lista as dependências do projeto e os scripts.
*   `tailwind.config.ts`: Configuração do Tailwind CSS.
*   `next.config.ts`: Configuração do Next.js.
    *   **Nota:** Este arquivo está configurado para ignorar erros de build do TypeScript e ESLint (`ignoreBuildErrors: true`, `eslint: { ignoreDuringBuilds: true }`). Isso pode ser útil durante o desenvolvimento rápido, mas para produção, é recomendável resolver esses erros.
*   `.env`: Arquivo para variáveis de ambiente (não versionado por padrão).
*   `.vscode/settings.json`: Contém configurações recomendadas para o VS Code, como habilitação de sugestões de IA inline.

## Como Usar o Projeto no GitHub

1.  **Adicione e Faça Commit das suas alterações:** Se você fez alterações locais que deseja salvar no seu repositório GitHub:
    ```bash
    git add .
    git commit -m "Sua mensagem de commit aqui"
    ```

2.  **Envie as alterações para o GitHub:**
    ```bash
    git push origin main # ou o nome da sua branch principal
    ```

3.  **Puxe as alterações mais recentes:** Se outras pessoas colaboraram ou se você fez alterações de outro computador:
    ```bash
    git pull origin main
    ```

Este `README.md` aprimorado deve ajudar qualquer pessoa (incluindo você) a entender como obter, configurar e executar o projeto a partir do GitHub. Lembre-se que o link para o repositório GitHub de exemplo no código da aplicação (`src/app/page.tsx` e `src/components/layout/app-sidebar-nav.tsx`) aponta para `https://github.com/firebase/studio` e deve ser substituído pelo link do seu próprio projeto.
