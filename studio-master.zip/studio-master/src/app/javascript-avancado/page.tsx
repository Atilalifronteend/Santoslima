
import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, Zap, Sigma, Cpu, Share2 } from "lucide-react";
import Image from "next/image";

export default function JavaScriptAvancadoTutorialPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2 flex items-center">
          <Zap className="h-10 w-10 mr-3 text-accent" />
          Tutorial de JavaScript Avançado
        </h1>
        <p className="text-lg text-muted-foreground">
          Aprofunde-se em JavaScript com features modernas, programação assíncrona, manipulação avançada do DOM e mais.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Recursos Modernos do ES6+</CardTitle>
          <CardDescription>Explore a sintaxe e funcionalidades introduzidas nas versões mais recentes do ECMAScript.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Image src="https://placehold.co/600x300.png" alt="Código JavaScript moderno" width={600} height={300} className="rounded-md my-4" data-ai-hint="modern javascript" />
          <ul className="list-disc list-inside space-y-2">
            <li><strong><code>let</code> e <code>const</code>:</strong> Declaração de variáveis com escopo de bloco.</li>
            <li><strong>Arrow Functions:</strong> Sintaxe concisa para funções (<code>(params) => { statements }</code>).</li>
            <li><strong>Template Literals:</strong> Strings com interpolação de variáveis (<code>`Olá ${nome}!`</code>).</li>
            <li><strong>Destructuring Assignment:</strong> Extrair valores de arrays ou propriedades de objetos em variáveis distintas.</li>
            <li><strong>Spread/Rest Operators (<code>...</code>):</strong> Expandir iteráveis ou agrupar argumentos de função.</li>
            <li><strong>Classes:</strong> Sintaxe mais clara para orientação a objetos baseada em protótipos.</li>
            <li><strong>Modules (<code>import</code>/<code>export</code>):</strong> Organizar código em arquivos reutilizáveis.</li>
          </ul>
          <CodeBlock language="javascript"
            code={`// Arrow Function & Template Literal
const greet = (name) => \`Olá, \${name}!\`;
console.log(greet("Mundo"));

// Destructuring
const person = { name: "Ana", age: 30 };
const { name, age } = person;
console.log(name, age);

// Spread Operator
const arr1 = [1, 2];
const arr2 = [...arr1, 3, 4]; // [1, 2, 3, 4]

// Classes
class Animal {
  constructor(name) {
    this.name = name;
  }
  speak() {
    console.log(\`\${this.name} faz um som.\`);
  }
}
const dog = new Animal("Rex");
dog.speak();`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Cpu className="mr-2 h-6 w-6 text-primary"/>Promises e Async/Await</CardTitle>
          <CardDescription>Gerenciando operações assíncronas de forma elegante.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Promises representam a conclusão (ou falha) eventual de uma operação assíncrona. Async/Await é uma sintaxe que permite escrever código assíncrono que se parece e se comporta um pouco como código síncrono.</p>
          <Image src="https://placehold.co/500x250.png" alt="Fluxo assíncrono" width={500} height={250} className="rounded-md my-4" data-ai-hint="async flow" />
          <CodeBlock language="javascript"
            code={`// Promise
function fetchData() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // resolve("Dados recebidos!");
      reject("Erro ao buscar dados!");
    }, 1000);
  });
}

fetchData()
  .then(data => console.log(data))
  .catch(error => console.error(error));

// Async/Await
async function processData() {
  try {
    console.log("Buscando dados...");
    const data = await fetchData(); // Pausa aqui até a Promise resolver
    console.log("Resultado com async/await:", data);
  } catch (error) {
    console.error("Erro com async/await:", error);
  }
}
processData();`}
          />
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Share2 className="mr-2 h-6 w-6 text-primary"/>APIs do Navegador (Browser APIs)</CardTitle>
          <CardDescription>Interagindo com o navegador e o ambiente do usuário.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Os navegadores fornecem diversas APIs para interagir com o sistema, buscar dados, armazenar informações e mais.</p>
          <Image src="https://placehold.co/600x250.png" alt="Conexões API" width={600} height={250} className="rounded-md my-4" data-ai-hint="api connection" />
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Fetch API:</strong> Para fazer requisições HTTP (substituindo o antigo XMLHttpRequest).</li>
            <li><strong>LocalStorage e SessionStorage:</strong> Para armazenar dados no navegador do cliente.</li>
            <li><strong>Geolocation API:</strong> Para obter a localização do usuário (com permissão).</li>
            <li><strong>History API:</strong> Para manipular o histórico de navegação.</li>
          </ul>
          <CodeBlock language="javascript"
            code={`// Exemplo Fetch API (simples)
async function getUsers() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users/1');
    if (!response.ok) {
      throw new Error(\`HTTP error! status: \${response.status}\`);
    }
    const data = await response.json();
    console.log("Usuário:", data.name);
  } catch (error) {
    console.error('Falha ao buscar usuário:', error);
  }
}
// getUsers(); // Descomente para testar

// Exemplo LocalStorage
// localStorage.setItem('username', 'devUser');
// const storedUser = localStorage.getItem('username');
// console.log("Usuário do LocalStorage:", storedUser);`}
          />
           <Alert variant="default" className="mt-2">
            <AlertTitle>Permissões e Segurança</AlertTitle>
            <AlertDescription>
              Muitas APIs do navegador, como Geolocation, exigem permissão explícita do usuário por motivos de privacidade e segurança.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Sigma className="mr-2 h-6 w-6 text-primary"/>Conceitos de Programação Funcional</CardTitle>
          <CardDescription>Introdução a paradigmas funcionais em JavaScript.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>JavaScript suporta conceitos de programação funcional que podem levar a um código mais declarativo, previsível e fácil de testar.</p>
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Imutabilidade:</strong> Evitar a modificação direta de estruturas de dados.</li>
            <li><strong>Funções Puras:</strong> Funções que, para a mesma entrada, sempre retornam a mesma saída e não têm efeitos colaterais.</li>
            <li><strong>High-Order Functions:</strong> Funções que operam em outras funções, seja tomando-as como argumentos ou retornando-as (ex: <code>map</code>, <code>filter</code>, <code>reduce</code>).</li>
          </ul>
          <CodeBlock language="javascript"
            code={`// Exemplo de map, filter, reduce (High-Order Functions)
const numbers = [1, 2, 3, 4, 5];

// map: cria um novo array transformando cada elemento
const doubled = numbers.map(num => num * 2); // [2, 4, 6, 8, 10]

// filter: cria um novo array com elementos que passam em um teste
const evens = numbers.filter(num => num % 2 === 0); // [2, 4]

// reduce: aplica uma função contra um acumulador para reduzir o array a um único valor
const sum = numbers.reduce((accumulator, currentValue) => accumulator + currentValue, 0); // 15

console.log({ doubled, evens, sum });`}
          />
        </CardContent>
      </Card>
      
       <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Manipulação Avançada do DOM</CardTitle>
          <CardDescription>Técnicas além do básico para interagir com a árvore de elementos HTML.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="list-disc list-inside space-y-2">
            <li><strong>Criação e Inserção Dinâmica de Elementos:</strong> Usar <code>document.createElement()</code>, <code>appendChild()</code>, <code>insertBefore()</code>, etc.</li>
            <li><strong>Event Delegation:</strong> Adicionar um único ouvinte de evento a um elemento pai para gerenciar eventos em múltiplos filhos.</li>
            <li><strong>Trabalhando com Atributos:</strong> <code>getAttribute()</code>, <code>setAttribute()</code>, <code>removeAttribute()</code>, <code>dataset</code> para atributos <code>data-*</code>.</li>
            <li><strong>Traversal do DOM:</strong> Navegar pela árvore com <code>parentNode</code>, <code>children</code>, <code>nextElementSibling</code>, <code>previousElementSibling</code>, etc.</li>
          </ul>
          <CodeBlock language="javascript"
            code={`// Criar e adicionar um item de lista
const newItem = document.createElement('li');
newItem.textContent = 'Novo item adicionado dinamicamente';
newItem.classList.add('dynamic-item');
// Supondo que você tenha um <ul id="myList"></ul> no seu HTML
// const list = document.getElementById('myList');
// list?.appendChild(newItem);

// Event Delegation (exemplo conceitual)
/*
document.getElementById('parentElement').addEventListener('click', function(event) {
  if (event.target && event.target.matches('button.childButton')) {
    console.log('Botão filho clicado:', event.target.textContent);
  }
});
*/`}
          />
        </CardContent>
      </Card>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Rumo à Maestria!</AlertTitle>
        <AlertDescription>
          JavaScript é um ecossistema vasto. Continue praticando, explore bibliotecas/frameworks como React, Vue ou Angular, e aprofunde-se em Node.js para desenvolvimento backend.
        </AlertDescription>
      </Alert>
    </div>
  );
}
