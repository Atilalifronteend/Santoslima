import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb } from "lucide-react";

export default function HtmlTutorialPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2">Tutorial de HTML Básico</h1>
        <p className="text-lg text-muted-foreground">
          Aprenda os fundamentos do HTML (HyperText Markup Language), a espinha dorsal de todas as páginas web.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">O que é HTML?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>HTML é a linguagem de marcação padrão para criar páginas da web. HTML descreve a estrutura de uma página da web usando elementos de marcação.</p>
          <p>Elementos HTML são os blocos de construção das páginas HTML e são representados por tags.</p>
          <Alert>
            <Lightbulb className="h-4 w-4" />
            <AlertTitle>Dica!</AlertTitle>
            <AlertDescription>
              Pense no HTML como o esqueleto de uma página web. Ele define a estrutura e o conteúdo.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Estrutura Básica de um Documento HTML</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Todo documento HTML começa com uma declaração de tipo de documento: <code>&lt;!DOCTYPE html&gt;</code>. O documento HTML em si começa com <code>&lt;html&gt;</code> e termina com <code>&lt;/html&gt;</code>.</p>
          <p>A parte visível do documento HTML está entre <code>&lt;body&gt;</code> e <code>&lt;/body&gt;</code>.</p>
          <CodeBlock
            language="html"
            code={`<!DOCTYPE html>
<html>
<head>
  <title>Título da Página</title>
</head>
<body>

  <h1>Meu Primeiro Cabeçalho</h1>
  <p>Meu primeiro parágrafo.</p>

</body>
</html>`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Tags HTML Comuns</CardTitle>
          <CardDescription>Aqui estão algumas das tags HTML mais usadas:</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">Cabeçalhos: <code>&lt;h1&gt;</code> a <code>&lt;h6&gt;</code></h3>
            <p>Usados para definir cabeçalhos HTML. <code>&lt;h1&gt;</code> define o cabeçalho mais importante. <code>&lt;h6&gt;</code> define o menos importante.</p>
            <CodeBlock language="html" code="<h1>Este é um cabeçalho h1</h1>\n<h2>Este é um cabeçalho h2</h2>" />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Parágrafos: <code>&lt;p&gt;</code></h3>
            <p>Usado para definir um parágrafo de texto.</p>
            <CodeBlock language="html" code="<p>Este é um parágrafo de texto.</p>\n<p>Este é outro parágrafo.</p>" />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Links: <code>&lt;a&gt;</code></h3>
            <p>Usado para criar hiperlinks. O atributo <code>href</code> especifica o destino do link.</p>
            <CodeBlock language="html" code='<a href="https://www.exemplo.com">Visite Exemplo.com</a>' />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Imagens: <code>&lt;img&gt;</code></h3>
            <p>Usado para incorporar uma imagem em uma página HTML. O atributo <code>src</code> especifica o caminho para a imagem e o atributo <code>alt</code> fornece um texto alternativo.</p>
            <CodeBlock language="html" code='<img src="imagem.jpg" alt="Descrição da Imagem" width="100" height="100">' />
            <Alert variant="destructive" className="mt-2">
              <AlertTitle>Importante!</AlertTitle>
              <AlertDescription>
                Sempre use o atributo <code>alt</code> para acessibilidade. Use imagens de <a href="https://placehold.co" target="_blank" rel="noopener noreferrer" className="underline">placehold.co</a> para testes, como <code>https://placehold.co/100x100.png</code>.
              </AlertDescription>
            </Alert>
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Listas: <code>&lt;ul&gt;</code>, <code>&lt;ol&gt;</code>, <code>&lt;li&gt;</code></h3>
            <p><code>&lt;ul&gt;</code> define uma lista não ordenada (com marcadores), <code>&lt;ol&gt;</code> define uma lista ordenada (com números), e <code>&lt;li&gt;</code> define um item da lista.</p>
            <CodeBlock language="html"
              code={`<ul>\n  <li>Café</li>\n  <li>Chá</li>\n  <li>Leite</li>\n</ul>\n\n<ol>\n  <li>Primeiro item</li>\n  <li>Segundo item</li>\n  <li>Terceiro item</li>\n</ol>`}
            />
          </div>
        </CardContent>
      </Card>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Próximos Passos</AlertTitle>
        <AlertDescription>
          Continue explorando mais tags HTML e pratique criando suas próprias páginas. Em seguida, aprenda CSS para estilizar suas páginas!
        </AlertDescription>
      </Alert>
    </div>
  );
}
