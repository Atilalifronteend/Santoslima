import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Combine, Lightbulb } from "lucide-react";

export default function IntegrationPage() {
  const htmlExample = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Demonstração</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1 id="main-title">Olá, Mundo!</h1>
        <p>Este é um exemplo simples de integração HTML, CSS e JavaScript.</p>
        <button id="color-button">Mudar Cor do Título</button>
        <button id="text-button">Mudar Texto do Título</button>
    </div>

    <script src="script.js"></script>
</body>
</html>`;

  const cssExample = `/* style.css */
body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background-color: #f0f0f0;
    margin: 0;
    transition: background-color 0.5s ease;
}

.container {
    text-align: center;
    background-color: white;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

h1 {
    color: #333;
    transition: color 0.3s ease;
}

button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    margin: 10px 5px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #0056b3;
}

.title-blue { color: blue; }
.title-green { color: green; }
.title-red { color: red; }`;

  const jsExample = `// script.js
document.addEventListener('DOMContentLoaded', () => {
    const titleElement = document.getElementById('main-title');
    const colorButton = document.getElementById('color-button');
    const textButton = document.getElementById('text-button');

    const colors = ['blue', 'green', 'red', 'purple', 'orange'];
    let currentColorIndex = 0;

    colorButton.addEventListener('click', () => {
        // Remove classes de cor anteriores
        titleElement.classList.remove('title-blue', 'title-green', 'title-red');
        
        // Aplica a nova cor via classe (poderia ser direto no style também)
        currentColorIndex = (currentColorIndex + 1) % colors.length;
        const newColor = colors[currentColorIndex];
        // Adiciona classe específica ou muda estilo diretamente
        if (newColor === 'blue') titleElement.classList.add('title-blue');
        else if (newColor === 'green') titleElement.classList.add('title-green');
        else if (newColor === 'red') titleElement.classList.add('title-red');
        else titleElement.style.color = newColor; // fallback para outras cores
    });

    textButton.addEventListener('click', () => {
        const newTexts = ["Você Consegue!", "Continue Aprendendo!", "JavaScript é Poderoso!", "Programar é Ganhar Dinheiro!"];
        const randomIndex = Math.floor(Math.random() * newTexts.length);
        titleElement.textContent = newTexts[randomIndex];
    });
});`;

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2">Integrando HTML, CSS e JavaScript</h1>
        <p className="text-lg text-muted-foreground">
          Veja como essas três tecnologias fundamentais trabalham juntas para criar páginas web interativas e bem apresentadas.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">A Tríade do Desenvolvimento Web</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>HTML, CSS e JavaScript são as três linguagens principais que você usará para construir websites:</p>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>HTML (HyperText Markup Language):</strong> Define a estrutura e o conteúdo da sua página. É o esqueleto.</li>
            <li><strong>CSS (Cascading Style Sheets):</strong> Descreve como os elementos HTML devem ser exibidos. É a aparência (cores, fontes, layout).</li>
            <li><strong>JavaScript:</strong> Adiciona interatividade e comportamento dinâmico à sua página. É o cérebro e os músculos.</li>
          </ul>
          <Alert>
            <Combine className="h-4 w-4" />
            <AlertTitle>Trabalhando em Harmonia</AlertTitle>
            <AlertDescription>
              Essas tecnologias são projetadas para funcionar juntas. O HTML fornece a base, o CSS estiliza essa base, e o JavaScript manipula ambos para criar experiências de usuário ricas.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Exemplo Prático</CardTitle>
          <CardDescription>Vamos criar uma página simples que demonstra a integração.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">1. O HTML (<code>index.html</code>)</h3>
            <p>Este arquivo define a estrutura da nossa página, incluindo um título, um parágrafo e dois botões. Ele também linka para nossos arquivos CSS e JavaScript.</p>
            <CodeBlock language="html" code={htmlExample} />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">2. O CSS (<code>style.css</code>)</h3>
            <p>Este arquivo contém as regras de estilo para os elementos HTML. Ele define fontes, cores, layout e efeitos de hover.</p>
            <CodeBlock language="css" code={cssExample} />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">3. O JavaScript (<code>script.js</code>)</h3>
            <p>Este arquivo adiciona interatividade. Ele espera o DOM carregar, depois adiciona ouvintes de evento aos botões. Um botão muda a cor do título e o outro muda o texto do título.</p>
            <CodeBlock language="javascript" code={jsExample} />
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Como Executar</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
            <p>Para ver este exemplo em ação:</p>
            <ol className="list-decimal list-inside space-y-1">
                <li>Crie três arquivos em uma pasta: <code>index.html</code>, <code>style.css</code>, e <code>script.js</code>.</li>
                <li>Copie e cole o conteúdo de cada bloco de código para o arquivo correspondente.</li>
                <li>Abra o arquivo <code>index.html</code> em seu navegador web.</li>
            </ol>
            <p className="mt-2">Você verá uma página com um título e dois botões. Clique nos botões para ver o JavaScript em ação, mudando a cor e o texto do título!</p>
        </CardContent>
      </Card>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Exploração Contínua</AlertTitle>
        <AlertDescription>
          Este é apenas um exemplo básico. À medida que você avança, aprenderá técnicas mais sofisticadas para integrar essas tecnologias, incluindo o uso de frameworks e bibliotecas.
        </AlertDescription>
      </Alert>
    </div>
  );
}
