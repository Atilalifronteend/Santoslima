import AiCodeAssistant from "@/components/ai/ai-code-assistant";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Sparkles, Lightbulb } from "lucide-react";

export default function AiAssistantPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2 flex items-center">
          <Sparkles className="h-10 w-10 mr-3 text-accent" />
          Assistente IA de Código
        </h1>
        <p className="text-lg text-muted-foreground">
          Precisa de uma ajudinha para começar? Descreva o que você quer criar em HTML, CSS ou JavaScript, e nossa IA gerará um snippet de código para você!
        </p>
      </header>

      <Card className="max-w-2xl mx-auto shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Gerador de Snippets de Código</CardTitle>
          <CardDescription>
            Forneça uma descrição clara e escolha a linguagem. A IA tentará gerar o código mais relevante possível.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AiCodeAssistant />
        </CardContent>
      </Card>

      <Alert className="max-w-2xl mx-auto">
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Dicas para Melhores Resultados:</AlertTitle>
        <AlertDescription>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Seja específico em sua descrição. Em vez de "um botão", diga "um botão azul com texto branco que diz 'Clique Aqui'".</li>
            <li>Para CSS, você pode pedir estilos para um seletor específico (ex: "estilos para uma classe .meu-card").</li>
            <li>Para JavaScript, descreva a funcionalidade desejada (ex: "uma função que soma dois números").</li>
            <li>A IA é uma ferramenta de auxílio. Revise e adapte o código gerado às suas necessidades.</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
}
