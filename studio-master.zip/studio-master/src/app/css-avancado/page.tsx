
import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, LayoutPanelLeft, Palette, SlidersHorizontal, Layers } from "lucide-react";
import Image from "next/image";

export default function CssAvancadoTutorialPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2 flex items-center">
          <LayoutPanelLeft className="h-10 w-10 mr-3 text-accent" />
          Tutorial de CSS Avançado
        </h1>
        <p className="text-lg text-muted-foreground">
          Domine técnicas avançadas de CSS para criar layouts complexos, animações e designs responsivos.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Flexbox</CardTitle>
          <CardDescription>Um modelo de layout unidimensional para organizar itens em linhas ou colunas.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Flexbox facilita o alinhamento e a distribuição de espaço entre itens em um container, mesmo quando o tamanho deles é desconhecido ou dinâmico.</p>
          <Image src="https://placehold.co/600x300.png" alt="Diagrama Flexbox" width={600} height={300} className="rounded-md my-4" data-ai-hint="layout diagram" />
          <p>Propriedades chave:</p>
          <ul className="list-disc list-inside space-y-1">
            <li><code>display: flex;</code> no container pai.</li>
            <li><code>flex-direction: row | column | row-reverse | column-reverse;</code></li>
            <li><code>justify-content</code>: alinhamento no eixo principal.</li>
            <li><code>align-items</code>: alinhamento no eixo transversal.</li>
            <li><code>flex-wrap: nowrap | wrap | wrap-reverse;</code></li>
            <li>Nos itens filhos: <code>flex-grow</code>, <code>flex-shrink</code>, <code>flex-basis</code>, <code>order</code>.</li>
          </ul>
          <CodeBlock language="css"
            code={`.container {\n  display: flex;\n  justify-content: space-around;\n  align-items: center;\n  height: 200px;\n  background-color: #eee;\n}\n\n.item {\n  width: 50px;\n  height: 50px;\n  background-color: var(--primary-foreground);\n  color: var(--primary);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: var(--radius);\n}`}
          />
          <CodeBlock language="html"
            code={`<div class="container">\n  <div class="item">1</div>\n  <div class="item">2</div>\n  <div class="item">3</div>\n</div>`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">CSS Grid Layout</CardTitle>
          <CardDescription>Um sistema de layout bidimensional, controlando linhas e colunas simultaneamente.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>CSS Grid é ideal para layouts de página mais complexos, permitindo que você defina áreas e alinhe conteúdo de forma precisa.</p>
          <Image src="https://placehold.co/600x350.png" alt="Diagrama CSS Grid" width={600} height={350} className="rounded-md my-4" data-ai-hint="grid structure" />
          <p>Propriedades chave:</p>
          <ul className="list-disc list-inside space-y-1">
            <li><code>display: grid;</code> no container pai.</li>
            <li><code>grid-template-columns</code> e <code>grid-template-rows</code>: definem as faixas da grade.</li>
            <li><code>grid-gap</code> (ou <code>gap</code>): espaçamento entre as células.</li>
            <li><code>grid-column</code> e <code>grid-row</code>: posicionam itens na grade.</li>
            <li><code>grid-template-areas</code>: para nomear áreas da grade.</li>
          </ul>
          <CodeBlock language="css"
            code={`.grid-container {\n  display: grid;\n  grid-template-columns: auto auto auto;\n  grid-template-rows: 80px 120px;\n  gap: 10px;\n  background-color: #eee;\n  padding: 10px;\n}\n\n.grid-item {\n  background-color: hsla(var(--primary-rgb), 0.8);\n  color: var(--primary-foreground);\n  border: 1px solid hsla(var(--primary-rgb), 1);\n  padding: 20px;\n  font-size: 1.2rem;\n  text-align: center;\n  border-radius: var(--radius);\n}\n\n.item1 {\n  grid-column: 1 / span 2; /* Ocupa 2 colunas */\n  grid-row: 1;\n}`}
          />
           <CodeBlock language="html"
            code={`<div class="grid-container">\n  <div class="grid-item item1">1</div>\n  <div class="grid-item">2</div>\n  <div class="grid-item">3</div>\n  <div class="grid-item">4</div>\n  <div class="grid-item">5</div>\n</div>`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Palette className="mr-2 h-6 w-6 text-primary"/>Transitions e Animations</CardTitle>
          <CardDescription>Adicionando movimento e interatividade visual aos seus elementos.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p><strong>Transitions:</strong> Permitem que mudanças de propriedade CSS ocorram suavemente ao longo de um período especificado.</p>
          <CodeBlock language="css"
            code={`.box-transition {\n  width: 100px;\n  height: 100px;\n  background-color: hsl(var(--accent));\n  transition: width 2s, height 2s, transform 2s;\n  border-radius: var(--radius);\n}\n\n.box-transition:hover {\n  width: 200px;\n  height: 200px;\n  transform: rotate(180deg);\n}`}
          />
          <p className="mt-4"><strong>Animations:</strong> Permitem animações mais complexas usando keyframes para definir estágios da animação.</p>
          <Image src="https://placehold.co/400x200.png" alt="Visualização de Animação" width={400} height={200} className="rounded-md my-4" data-ai-hint="motion graphics" />
          <CodeBlock language="css"
            code={`@keyframes slidein {\n  from {\n    transform: translateX(0%);\n    opacity: 0;\n  }\n  to {\n    transform: translateX(100%);\n    opacity: 1;\n  }\n}\n\n.animated-element {\n  width: 100px;\n  height: 50px;\n  background-color: hsl(var(--primary));\n  animation-name: slidein;\n  animation-duration: 3s;\n  animation-iteration-count: infinite;\n  animation-direction: alternate;\n  border-radius: var(--radius);\n}`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Layers className="mr-2 h-6 w-6 text-primary"/>Design Responsivo com Media Queries</CardTitle>
          <CardDescription>Adaptando seu layout para diferentes tamanhos de tela e dispositivos.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Media queries permitem aplicar estilos CSS condicionalmente com base nas características do dispositivo, como largura da tela.</p>
          <Image src="https://placehold.co/600x250.png" alt="Dispositivos Responsivos" width={600} height={250} className="rounded-md my-4" data-ai-hint="responsive devices" />
          <CodeBlock language="css"
            code={`body {\n  font-size: 16px;\n}\n\n/* Para telas menores que 600px */\n@media (max-width: 600px) {\n  body {\n    font-size: 14px;\n  }\n  .sidebar {\n    display: none; /* Esconder sidebar em telas pequenas */\n  }\n}\n\n/* Para telas maiores que 900px */\n@media (min-width: 900px) {\n  .container {\n    max-width: 1200px;\n    margin: 0 auto;\n  }\n}`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><SlidersHorizontal className="mr-2 h-6 w-6 text-primary"/>Seletores Avançados e Variáveis CSS</CardTitle>
          <CardDescription>Refinando a seleção de elementos e gerenciando valores de estilo.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <h3 className="font-semibold text-lg">Seletores Avançados</h3>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Pseudo-classes:</strong> <code>:nth-child(n)</code>, <code>:not()</code>, <code>:hover</code>, <code>:focus-within</code>.</li>
            <li><strong>Pseudo-elementos:</strong> <code>::before</code>, <code>::after</code>, <code>::first-letter</code>, <code>::selection</code>.</li>
            <li><strong>Seletores de Atributo:</strong> <code>[target="_blank"]</code>, <code>[href^="https"]</code>, <code>[class*="btn-"]</code>.</li>
          </ul>
          <CodeBlock language="css"
            code={`/* Estiliza o terceiro item de uma lista */\nli:nth-child(3) {\n  color: hsl(var(--accent));\n}\n\n/* Adiciona conteúdo antes de um parágrafo com a classe 'special' */\n.special::before {\n  content: "✨ ";\n}\n\n/* Seleciona links que abrem em nova aba */\na[target="_blank"] {\n  text-decoration: underline dotted;\n}`}
          />

          <h3 className="font-semibold text-lg mt-6">Variáveis CSS (Custom Properties)</h3>
          <p>Permitem definir valores reutilizáveis em seu CSS, facilitando a manutenção e a criação de temas.</p>
          <CodeBlock language="css"
            code={`:root {\n  --main-bg-color: #f0f0f0;\n  --main-text-color: #333;\n  --primary-accent: hsl(var(--accent));\n}\n\nbody {\n  background-color: var(--main-bg-color);\n  color: var(--main-text-color);\n}\n\n.button-primary {\n  background-color: var(--primary-accent);\n  color: white;\n}`}
          />
        </CardContent>
      </Card>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Pratique e Explore!</AlertTitle>
        <AlertDescription>
          CSS é uma linguagem poderosa com muitos recursos. A melhor forma de aprender é praticando e construindo projetos. Consulte documentações como MDN para se aprofundar.
        </AlertDescription>
      </Alert>
    </div>
  );
}

