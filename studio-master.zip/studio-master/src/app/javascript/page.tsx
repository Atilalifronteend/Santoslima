import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, Braces } from "lucide-react";

export default function JavaScriptTutorialPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2">Tutorial de JavaScript Básico</h1>
        <p className="text-lg text-muted-foreground">
          Introdução ao JavaScript, a linguagem de programação que torna as páginas web interativas e dinâmicas.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">O que é JavaScript?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>JavaScript (JS) é uma linguagem de programação de alto nível, interpretada, usada principalmente para desenvolvimento web front-end.</p>
          <p>Ela permite criar conteúdo dinamicamente atualizado, controlar multimídia, animar imagens e praticamente tudo o mais em uma página web.</p>
          <Alert>
            <Braces className="h-4 w-4" />
            <AlertTitle>Interatividade!</AlertTitle>
            <AlertDescription>
              Se HTML é o esqueleto e CSS é a aparência, JavaScript é o cérebro e os músculos, permitindo que a página reaja às ações do usuário.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Adicionando JavaScript a uma Página HTML</CardTitle>
          <CardDescription>JavaScript pode ser adicionado diretamente em seu HTML ou em arquivos .js externos.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">Usando a tag <code>&lt;script&gt;</code></h3>
            <p>Você pode colocar código JavaScript dentro da tag <code>&lt;script&gt;</code>, geralmente no final do <code>&lt;body&gt;</code> ou no <code>&lt;head&gt;</code>.</p>
            <CodeBlock language="html"
              code={`<!DOCTYPE html>
<html>
<head>
  <title>Página com JavaScript</title>
</head>
<body>
  <p id="demo"></p>

  <script>
    document.getElementById("demo").innerHTML = "Olá, JavaScript!";
  </script>
</body>
</html>`}
            />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">Arquivos JavaScript Externos</h3>
            <p>Para código mais complexo ou reutilizável, é melhor usar arquivos .js externos, vinculados com o atributo <code>src</code> da tag <code>&lt;script&gt;</code>.</p>
            <CodeBlock language="html" code='<script src="meuscript.js"></script>' />
            <CodeBlock language="javascript"
              code={`// meuscript.js
function minhaFuncao() {
  alert("Botão clicado!");
}

// Exemplo de como chamar a função (geralmente atrelado a um evento em HTML)
// <button onclick="minhaFuncao()">Clique Aqui</button>`}
            />
             <Alert variant="default" className="mt-2 bg-secondary text-secondary-foreground border-secondary">
              <AlertTitle>Boas Práticas</AlertTitle>
              <AlertDescription>
                Colocar scripts no final do <code>&lt;body&gt;</code> geralmente melhora a velocidade de carregamento percebida da página, pois permite que o HTML e CSS sejam renderizados primeiro.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Conceitos Básicos de JavaScript</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Alguns conceitos fundamentais:</p>
          <ul className="list-disc list-inside space-y-2">
            <li>
              <strong>Variáveis:</strong> Usadas para armazenar dados. Declaradas com <code>let</code>, <code>const</code> (ou <code>var</code>, mais antigo).
              <CodeBlock language="javascript" code="let nome = 'Alice';\nconst idade = 30;" />
            </li>
            <li>
              <strong>Tipos de Dados:</strong> Strings, Numbers, Booleans, Objects, Arrays, etc.
              <CodeBlock language="javascript" code="let texto = \"Olá\"; // String\nlet numero = 10; // Number\nlet ativo = true; // Boolean" />
            </li>
            <li>
              <strong>Funções:</strong> Blocos de código reutilizáveis que realizam uma tarefa específica.
              <CodeBlock language="javascript"
                code={`function saudacao(nome) {\n  return "Olá, " + nome + "!";\n}\n\nlet mensagem = saudacao("Mundo"); // mensagem será "Olá, Mundo!"`}
              />
            </li>
            <li>
              <strong>Manipulação do DOM:</strong> JavaScript pode interagir e modificar o HTML e CSS de uma página (Document Object Model).
              <CodeBlock language="javascript" code='// Encontra um elemento HTML pelo ID e muda seu conteúdo\ndocument.getElementById("titulo").innerHTML = "Novo Título";' />
            </li>
             <li>
              <strong>Eventos:</strong> JavaScript pode reagir a eventos do usuário como cliques, movimentos do mouse, pressionamentos de tecla, etc.
              <CodeBlock language="html" code='<button onclick="alert(\'Clicou!\')">Clique em mim</button>' />
            </li>
          </ul>
        </CardContent>
      </Card>
      
      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Mundo de Possibilidades!</AlertTitle>
        <AlertDescription>
          JavaScript é uma linguagem poderosa. Aprenda sobre arrays, objetos, loops, condicionais, ES6+ features, frameworks (React, Angular, Vue) e Node.js para backend. Agora, veja como integrar tudo!
        </AlertDescription>
      </Alert>
    </div>
  );
}
