
import type { Metadata } from 'next';
import './globals.css';
import { SidebarProvider } from '@/components/ui/sidebar';
import AppHeader from '@/components/layout/app-header';
import AppSidebarNav from '@/components/layout/app-sidebar-nav';
import { Toaster } from "@/components/ui/toaster";
import Image from 'next/image';

export const metadata: Metadata = {
  title: 'Programar é Ganhar Dinheiro',
  description: 'Seu guia para aprender desenvolvimento web.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Source+Code+Pro:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased">
        {/* Imagem oculta para fornecer dica de IA para o plano de fundo global, se necessário */}
        <Image 
          src="https://placehold.co/1920x1080.png" 
          alt="Plano de fundo de código suave"
          data-ai-hint="abstract code lines" /* Dica para IA encontrar imagem de fundo */
          width={1} 
          height={1} 
          className="hidden" 
          priority={false} /* Não é crítico para o LCP */
        />
        <SidebarProvider>
          <div className="flex min-h-screen">
            <AppSidebarNav />
            <div className="flex flex-1 flex-col bg-transparent"> {/* bg-background removido para o efeito do body::before funcionar melhor */}
              <AppHeader />
              <main className="flex-grow overflow-y-auto p-4 md:p-8">
                {children}
              </main>
            </div>
          </div>
        </SidebarProvider>
        <Toaster />
      </body>
    </html>
  );
}

    