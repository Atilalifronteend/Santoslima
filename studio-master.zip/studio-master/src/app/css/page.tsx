import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, Palette } from "lucide-react";

export default function CssTutorialPage() {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2">Tutorial de CSS Básico</h1>
        <p className="text-lg text-muted-foreground">
          Descubra como usar CSS (Cascading Style Sheets) para estilizar suas páginas HTML e torná-las visualmente atraentes.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">O que é CSS?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>CSS é uma linguagem de folha de estilo usada para descrever a apresentação de um documento escrito em HTML ou XML.</p>
          <p>CSS descreve como os elementos HTML devem ser exibidos na tela, no papel ou em outras mídias.</p>
          <Alert>
            <Palette className="h-4 w-4" />
            <AlertTitle>Visualizando!</AlertTitle>
            <AlertDescription>
              Se o HTML é o esqueleto, o CSS é a pele, as roupas e a maquiagem da sua página web. Ele cuida da aparência!
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Como Adicionar CSS a uma Página HTML</CardTitle>
          <CardDescription>Existem três maneiras de inserir CSS:</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2">1. CSS Externo</h3>
            <p>Com um arquivo CSS externo, você pode alterar a aparência de um site inteiro alterando apenas um arquivo. Cada página HTML deve incluir uma referência ao arquivo CSS externo dentro do elemento <code>&lt;link&gt;</code>, dentro da seção <code>&lt;head&gt;</code>.</p>
            <CodeBlock language="html" code='<head>\n  <link rel="stylesheet" href="mystyle.css">\n</head>' />
            <CodeBlock language="css" code={`/* mystyle.css */\nbody {\n  background-color: lightblue;\n}\n\nh1 {\n  color: navy;\n  margin-left: 20px;\n}`} />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">2. CSS Interno</h3>
            <p>Um CSS interno é usado se uma única página HTML tiver um estilo único. O CSS interno é definido dentro do elemento <code>&lt;style&gt;</code>, dentro da seção <code>&lt;head&gt;</code>.</p>
            <CodeBlock language="html"
              code={`<head>\n  <style>\n    body {\n      background-color: linen;\n    }\n    h1 {\n      color: maroon;\n      margin-left: 40px;\n    }\n  </style>\n</head>`}
            />
          </div>
          <div>
            <h3 className="font-semibold text-lg mb-2">3. CSS Inline</h3>
            <p>Um estilo inline pode ser usado para aplicar um estilo único a um único elemento. Para usar estilos inline, adicione o atributo <code>style</code> ao elemento relevante.</p>
            <CodeBlock language="html" code='<h1 style="color:blue;text-align:center;">Este é um Cabeçalho</h1>\n<p style="color:red;">Este é um parágrafo.</p>' />
             <Alert variant="destructive" className="mt-2">
              <AlertTitle>Cuidado!</AlertTitle>
              <AlertDescription>
                Estilos inline geralmente não são recomendados, pois misturam conteúdo e apresentação, tornando a manutenção mais difícil. Prefira CSS externo.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Seletores CSS e Propriedades Comuns</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Seletores CSS são usados para "encontrar" (ou selecionar) os elementos HTML que você deseja estilizar.</p>
          <ul className="list-disc list-inside space-y-1">
            <li><strong>Seletor de elemento:</strong> Seleciona elementos HTML com base no nome da tag. Ex: <code>p</code>, <code>h1</code>.</li>
            <li><strong>Seletor de ID:</strong> Usa o atributo id de um elemento HTML para selecionar um elemento específico. Ex: <code>#meuId</code>.</li>
            <li><strong>Seletor de classe:</strong> Seleciona elementos HTML com um atributo de classe específico. Ex: <code>.minhaClasse</code>.</li>
          </ul>
          <p className="mt-4">Algumas propriedades CSS comuns:</p>
          <ul className="list-disc list-inside space-y-1">
            <li><code>color</code>: Define a cor do texto.</li>
            <li><code>background-color</code>: Define a cor de fundo de um elemento.</li>
            <li><code>font-size</code>: Define o tamanho da fonte.</li>
            <li><code>font-family</code>: Especifica a família da fonte para o texto.</li>
            <li><code>margin</code>: Define as margens externas de um elemento.</li>
            <li><code>padding</code>: Define o preenchimento interno de um elemento.</li>
            <li><code>border</code>: Define uma borda ao redor de um elemento.</li>
          </ul>
          <CodeBlock language="css"
            code={`/* Seletor de elemento */
p {
  color: green;
  font-size: 16px;
}

/* Seletor de ID */
#logo {
  width: 100px;
  height: 50px;
}

/* Seletor de classe */
.destaque {
  background-color: yellow;
  font-weight: bold;
}`}
          />
        </CardContent>
      </Card>
      
      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Continue Aprendendo!</AlertTitle>
        <AlertDescription>
          CSS é vasto! Explore o Box Model, Flexbox, Grid, responsividade e muito mais para criar layouts incríveis. Em seguida, aprenda JavaScript para adicionar interatividade!
        </AlertDescription>
      </Alert>
    </div>
  );
}
