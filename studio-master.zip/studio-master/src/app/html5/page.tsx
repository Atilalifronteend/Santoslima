
"use client";

import * as React from "react";
import CodeBlock from "@/components/shared/code-block";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Lightbulb, Code2, Film, Edit3 } from "lucide-react";
import Image from "next/image";

export default function Html5TutorialPage() {
  const [currentYear, setCurrentYear] = React.useState<number | null>(null);

  React.useEffect(() => {
    setCurrentYear(new Date().getFullYear());
  }, []);

  const footerYearDisplay = currentYear !== null ? currentYear : '...';

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2 flex items-center">
          <Code2 className="h-10 w-10 mr-3 text-accent" />
          Tutorial de HTML5 Avançado
        </h1>
        <p className="text-lg text-muted-foreground">
          Explore os recursos semânticos e modernos do HTML5 para criar páginas web mais ricas e estruturadas.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">O que é HTML5?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>HTML5 é a versão mais recente do HTML, trazendo novas tags, atributos e APIs que enriquecem a web. Ele foca em semântica, multimídia, gráficos e interatividade.</p>
          <Alert>
            <Lightbulb className="h-4 w-4" />
            <AlertTitle>Evolução Web!</AlertTitle>
            <AlertDescription>
              HTML5 torna o código mais claro para navegadores e desenvolvedores, além de habilitar funcionalidades que antes exigiam plugins.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Elementos Semânticos</CardTitle>
          <CardDescription>HTML5 introduziu novos elementos para descrever melhor a estrutura do conteúdo:</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ul className="list-disc list-inside space-y-2">
            <li><code>&lt;header&gt;</code>: Define um cabeçalho para um documento ou seção.</li>
            <li><code>&lt;nav&gt;</code>: Define um conjunto de links de navegação.</li>
            <li><code>&lt;main&gt;</code>: Especifica o conteúdo principal de um documento.</li>
            <li><code>&lt;article&gt;</code>: Define conteúdo autônomo e independente.</li>
            <li><code>&lt;section&gt;</code>: Define uma seção em um documento.</li>
            <li><code>&lt;aside&gt;</code>: Define conteúdo à parte do conteúdo principal (como uma barra lateral).</li>
            <li><code>&lt;footer&gt;</code>: Define um rodapé para um documento ou seção.</li>
            <li><code>&lt;figure&gt;</code> e <code>&lt;figcaption&gt;</code>: Usados para agrupar conteúdo de mídia (imagens, diagramas) com uma legenda.</li>
            <li><code>&lt;time&gt;</code>: Define uma data ou hora específica.</li>
            <li><code>&lt;mark&gt;</code>: Define texto marcado ou destacado.</li>
          </ul>
          <CodeBlock
            language="html"
            code={`<body>
  <header>
    <h1>Meu Site Incrível</h1>
    <nav>
      <a href="/">Início</a> | <a href="/sobre">Sobre</a>
    </nav>
  </header>
  <main>
    <article>
      <h2>Título do Artigo</h2>
      <p>Conteúdo do artigo aqui...</p>
      <figure>
        <Image src="https://placehold.co/300x200.png" alt="Exemplo de imagem" width={300} height={200} data-ai-hint="technology abstract" />
        <figcaption>Legenda para a imagem.</figcaption>
      </figure>
    </article>
    <aside>
      <h3>Links Relacionados</h3>
      <p>Algum conteúdo lateral.</p>
    </aside>
  </main>
  <footer>
    <p>&copy; <time dateTime="${footerYearDisplay}">${footerYearDisplay}</time> Meu Site Incrível.</p>
  </footer>
</body>`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Edit3 className="mr-2 h-6 w-6 text-primary"/>Formulários HTML5</CardTitle>
          <CardDescription>Novos tipos de input e atributos para formulários mais inteligentes:</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>Novos tipos de input como <code>email</code>, <code>url</code>, <code>date</code>, <code>time</code>, <code>number</code>, <code>range</code>, <code>search</code>, <code>color</code>.</p>
          <p>Novos atributos como <code>placeholder</code>, <code>required</code>, <code>pattern</code>, <code>autofocus</code>, <code>multiple</code>.</p>
          <p>Elemento <code>&lt;datalist&gt;</code> para fornecer sugestões em campos de input.</p>
          <CodeBlock
            language="html"
            code={`<form>
  <label for="email">Email:</label>
  <input type="email" id="email" name="email" required placeholder="seu@email.com">

  <label for="nascimento">Data de Nascimento:</label>
  <input type="date" id="nascimento" name="nascimento">

  <label for="website">Seu site:</label>
  <input type="url" id="website" name="website" placeholder="https://example.com">
  
  <label for="satisfacao">Nível de Satisfação (1-10):</label>
  <input type="range" id="satisfacao" name="satisfacao" min="1" max="10">

  <input type="submit" value="Enviar">
</form>`}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl flex items-center"><Film className="mr-2 h-6 w-6 text-primary"/>Multimídia: <code>&lt;audio&gt;</code> e <code>&lt;video&gt;</code></CardTitle>
          <CardDescription>Incorporar áudio e vídeo nativamente no navegador.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>O elemento <code>&lt;audio&gt;</code> permite incorporar conteúdo de áudio, enquanto <code>&lt;video&gt;</code> permite incorporar conteúdo de vídeo. Ambos suportam o atributo <code>controls</code> para exibir controles padrão do navegador.</p>
          <CodeBlock
            language="html"
            code={`<video controls width="320" height="240" poster="https://placehold.co/320x240.png" data-ai-hint="video placeholder">
  <source src="meu-video.mp4" type="video/mp4">
  <source src="meu-video.webm" type="video/webm">
  <track kind="captions" src="legendas_pt.vtt" srclang="pt" label="Português">
  Seu navegador não suporta a tag de vídeo.
</video>

<audio controls>
  <source src="minha-musica.mp3" type="audio/mpeg">
  <source src="minha-musica.ogg" type="audio/ogg">
  Seu navegador não suporta a tag de áudio.
</audio>`}
          />
          <Alert variant="default" className="mt-2">
            <AlertTitle>Acessibilidade</AlertTitle>
            <AlertDescription>
              Use o elemento <code>&lt;track&gt;</code> para fornecer legendas e transcrições para seu conteúdo de vídeo e áudio.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Gráficos com <code>&lt;canvas&gt;</code> e <code>&lt;svg&gt;</code></CardTitle>
          <CardDescription>HTML5 facilita a criação de gráficos dinâmicos e vetoriais.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p><code>&lt;canvas&gt;</code>: Usado para desenhar gráficos, animações e outros visuais via JavaScript. É baseado em pixels.</p>
          <p><code>&lt;svg&gt;</code>: Scalable Vector Graphics. Define gráficos usando XML. Ideal para logotipos e ilustrações que precisam escalar bem.</p>
          <CodeBlock
            language="html"
            code={`<!-- Exemplo de Canvas (requer JavaScript para desenhar) -->
<canvas id="meuCanvas" width="200" height="100" style="border:1px solid #ccc;"></canvas>
<script>
  // const canvas = document.getElementById('meuCanvas');
  // if (canvas.getContext) {
  //   const ctx = canvas.getContext('2d');
  //   ctx.fillStyle = 'blue';
  //   ctx.fillRect(10, 10, 100, 50);
  // }
</script>

<!-- Exemplo de SVG -->
<svg width="100" height="100">
  <circle cx="50" cy="50" r="40" stroke="navy" stroke-width="3" fill="lightblue" />
  <text x="50" y="55" text-anchor="middle" fill="black" font-size="12">SVG!</text>
</svg>`}
          />
        </CardContent>
      </Card>

       <Card>
        <CardHeader>
          <CardTitle className="font-headline text-2xl">Outras APIs Importantes</CardTitle>
          <CardDescription>HTML5 também especificou ou padronizou várias APIs JavaScript:</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          <ul className="list-disc list-inside">
            <li><strong>Geolocation API:</strong> Para obter a localização geográfica do usuário (com permissão).</li>
            <li><strong>Web Storage (localStorage e sessionStorage):</strong> Para armazenar dados no navegador do cliente.</li>
            <li><strong>Web Workers:</strong> Para executar scripts em threads de segundo plano.</li>
            <li><strong>Drag and Drop API:</strong> Para implementar funcionalidade de arrastar e soltar.</li>
            <li><strong>Server-Sent Events (SSE):</strong> Para permitir que um servidor envie atualizações para o cliente.</li>
          </ul>
        </CardContent>
      </Card>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertTitle>Continue Explorando!</AlertTitle>
        <AlertDescription>
          HTML5 é vasto e cheio de recursos. Aprofunde-se na documentação e pratique para dominar o desenvolvimento web moderno.
        </AlertDescription>
      </Alert>
    </div>
  );
}
    
