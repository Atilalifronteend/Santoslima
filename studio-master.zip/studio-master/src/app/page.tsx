
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, BookOpenText, Code, Palette, Braces, Combine, Sparkles, Code2, LayoutPanelLeft, Zap, Github } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export default function HomePage() {
  const features = [
    { title: "HTML Essencial", description: "Aprenda a estrutura fundamental das páginas web.", icon: Code, href: "/html", color: "text-red-500" },
    { title: "HTML5 Avançado", description: "Explore os recursos semânticos e modernos do HTML5.", icon: Code2, href: "/html5", color: "text-red-600" },
    { title: "CSS Básico", description: "Estilize suas páginas e dê vida aos seus designs.", icon: Palette, href: "/css", color: "text-blue-500" },
    { title: "CSS Avançado", description: "Layouts complexos, animações e responsividade.", icon: LayoutPanelLeft, href: "/css-avancado", color: "text-sky-500" },
    { title: "JavaScript Básico", description: "Adicione interatividade e lógica às suas aplicações.", icon: Braces, href: "/javascript", color: "text-yellow-500" },
    { title: "JavaScript Avançado", description: "ES6+, assincronismo, APIs e mais.", icon: Zap, href: "/javascript-avancado", color: "text-amber-500" },
    { title: "Integrando Tudo", description: "Veja como HTML, CSS e JS trabalham juntos.", icon: Combine, href: "/integration", color: "text-green-500" },
    { title: "Assistente IA", description: "Gere snippets de código com nossa IA.", icon: Sparkles, href: "/ai-assistant", color: "text-purple-500" },
    { title: "Recursos Adicionais", description: "Explore links e materiais extras para aprofundar.", icon: BookOpenText, href: "/extra-links", color: "text-orange-500" },
    { title: "Código Fonte (Exemplo GitHub)", description: "Acesse o código-fonte de exemplo. Substitua o URL 'https://github.com/firebase/studio' pelo link do seu projeto!", icon: Github, href: "https://github.com/firebase/studio", color: "text-slate-700", target: "_blank" },
  ];

  return (
    <div className="container mx-auto py-8">
      <section className="text-center mb-12 md:mb-16">
        <h1 className="text-4xl md:text-5xl font-bold font-headline mb-4 text-primary">
          Bem-vindo ao Programar é Ganhar Dinheiro!
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          Sua jornada para se tornar um desenvolvedor web começa aqui. Explore nossos tutoriais e ferramentas para construir suas primeiras páginas e aplicações web.
        </p>
      </section>

      <section className="mb-12 md:mb-16">
        <Image 
          src="https://placehold.co/1200x400.png" 
          alt="Ilustração de um programador codificando em um ambiente de desenvolvimento" 
          width={1200} 
          height={400} 
          className="rounded-lg shadow-lg mx-auto"
          data-ai-hint="programmer coding"
        />
      </section>

      <section className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-12 md:mb-16">
        {features.map((feature) => (
          <Card key={feature.title} className="hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center gap-4 pb-2">
              <feature.icon className={`h-10 w-10 ${feature.color}`} />
              <CardTitle className="font-headline text-xl">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="mb-4">{feature.description}</CardDescription>
              <Button variant="outline" asChild className="w-full hover:bg-accent hover:text-accent-foreground transition-colors">
                <Link href={feature.href} target={feature.target || "_self"} rel={feature.target === "_blank" ? "noopener noreferrer" : undefined}>
                  {feature.target === "_blank" ? "Ver Repositório de Exemplo" : "Começar Aprender"} <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="text-center">
        <h2 className="text-3xl font-bold font-headline mb-6 text-primary">Pronto para Codificar?</h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
          Não espere mais! Mergulhe nos tutoriais ou peça ajuda ao nosso assistente IA para criar seus primeiros códigos.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button size="lg" asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Link href="/html">
              Iniciar com HTML
            </Link>
          </Button>
          <Button size="lg" variant="secondary" asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/ai-assistant">
              Usar Assistente IA <Sparkles className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
    
