import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, BookOpenText } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

interface Resource {
  title: string;
  description: string;
  href: string;
  logoUrl?: string;
  category: string;
  aiHint?: string;
}

const resources: Resource[] = [
  {
    title: "MDN Web Docs (Mozilla Developer Network)",
    description: "Documentação completa e detalhada sobre HTML, CSS, JavaScript e outras tecnologias web. Mantido pela Mozilla.",
    href: "https://developer.mozilla.org/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Documentação",
    aiHint: "Mozilla logo"
  },
  {
    title: "W3Schools",
    description: "Tutoriais, referências e exemplos práticos para aprender desenvolvimento web de forma interativa.",
    href: "https://www.w3schools.com/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Tutoriais",
    aiHint: "W3Schools logo"
  },
  {
    title: "freeCodeCamp",
    description: "Plataforma de aprendizado gratuita com currículo extenso, projetos práticos e certificações em desenvolvimento web.",
    href: "https://www.freecodecamp.org/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Cursos Interativos",
    aiHint: "freeCodeCamp logo"
  },
  {
    title: "CSS-Tricks",
    description: "Artigos, guias e dicas sobre CSS, HTML, JavaScript e design web. Ótimo para truques e técnicas avançadas.",
    href: "https://css-tricks.com/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Artigos e Guias",
    aiHint: "CSS Tricks logo"
  },
  {
    title: "Stack Overflow",
    description: "Comunidade de perguntas e respostas para desenvolvedores. Encontre soluções para problemas específicos.",
    href: "https://stackoverflow.com/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Comunidade",
    aiHint: "StackOverflow logo"
  },
  {
    title: "Can I use...",
    description: "Verifique a compatibilidade de recursos HTML, CSS e JavaScript em diferentes navegadores.",
    href: "https://caniuse.com/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Ferramentas",
    aiHint: "compatibility check"
  },
  {
    title: "Smashing Magazine",
    description: "Artigos de alta qualidade sobre design web, desenvolvimento front-end, UX e mobile.",
    href: "https://www.smashingmagazine.com/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Artigos e Guias",
    aiHint: "Smashing Magazine"
  },
  {
    title: "CodePen",
    description: "Playground online para testar snippets de HTML, CSS e JavaScript. Inspire-se com projetos da comunidade.",
    href: "https://codepen.io/",
    logoUrl: "https://placehold.co/100x50.png",
    category: "Ferramentas",
    aiHint: "CodePen logo"
  },
];

export default function ExtraLinksPage() {
  const categories = Array.from(new Set(resources.map(r => r.category)));

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold font-headline text-primary mb-2">Links Extras e Recursos</h1>
        <p className="text-lg text-muted-foreground">
          Continue sua jornada de aprendizado com estes recursos valiosos selecionados para você.
        </p>
      </header>

      {categories.map(category => (
        <section key={category} className="mb-12">
          <h2 className="text-2xl font-semibold font-headline mb-6 flex items-center">
            <BookOpenText className="h-6 w-6 mr-3 text-accent" />
            {category}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {resources.filter(r => r.category === category).map((resource) => (
              <Card key={resource.title} className="flex flex-col hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  {resource.logoUrl && (
                    <div className="mb-3 h-12 flex items-center">
                      <Image 
                        src={resource.logoUrl} 
                        alt={`${resource.title} logo`} 
                        width={100} 
                        height={50} 
                        className="max-h-12 w-auto object-contain"
                        data-ai-hint={resource.aiHint || "logo"}
                        />
                    </div>
                  )}
                  <CardTitle className="font-headline text-xl">{resource.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <CardDescription>{resource.description}</CardDescription>
                </CardContent>
                <div className="p-6 pt-0">
                  <Button asChild variant="outline" className="w-full hover:bg-accent hover:text-accent-foreground transition-colors">
                    <Link href={resource.href} target="_blank" rel="noopener noreferrer">
                      Visitar Site <ExternalLink className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
