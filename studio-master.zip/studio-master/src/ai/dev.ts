import { config } from 'dotenv';
config();

import '@/ai/flows/generate-code-snippet.ts';