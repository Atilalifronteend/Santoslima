
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { cn } from "@/lib/utils";
import {
  Home,
  FileCode,
  Palette,
  Braces,
  Combine,
  BookOpenText,
  Sparkles,
  Github,
  LeafIcon,
  Code2,
  LayoutPanelLeft, // Para CSS Avançado
  Zap, // Para JavaScript Avançado
} from "lucide-react";

const navItems = [
  { href: "/", label: "Início", icon: Home },
  { href: "/html", label: "Tutorial HTML", icon: FileCode },
  { href: "/html5", label: "HTML5 Avançado", icon: Code2 },
  { href: "/css", label: "Tutorial CSS", icon: Palette },
  { href: "/css-avancado", label: "CSS Avançado", icon: LayoutPanelLeft },
  { href: "/javascript", label: "Tutorial JavaScript", icon: Braces },
  { href: "/javascript-avancado", label: "JavaScript Avançado", icon: Zap },
  { href: "/integration", label: "Integração", icon: Combine },
  { href: "/extra-links", label: "Links Extras", icon: BookOpenText },
  { href: "/ai-assistant", label: "Assistente IA", icon: Sparkles },
];

export default function AppSidebarNav() {
  const pathname = usePathname();

  const handleGitHubClick = () => {
    // Lembre-se de substituir este URL pelo URL do seu projeto!
    window.open("https://github.com/firebase/studio", "_blank", "noopener,noreferrer");
  };

  return (
    <Sidebar side="left" collapsible="icon" className="border-r">
      <SidebarHeader className="border-b">
         <Link href="/" className="flex items-center gap-2 font-semibold group-data-[collapsible=icon]:justify-center">
            <LeafIcon className="h-7 w-7 text-primary group-data-[collapsible=icon]:h-6 group-data-[collapsible=icon]:w-6" />
            <span className="text-lg font-headline group-data-[collapsible=icon]:hidden">Programar é Ganhar Dinheiro</span>
          </Link>
      </SidebarHeader>
      <SidebarContent className="p-2">
        <SidebarMenu>
          {navItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <Link href={item.href} legacyBehavior passHref>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))}
                  tooltip={item.label}
                  className={cn(
                    "justify-start",
                    (pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href))) && "bg-sidebar-accent text-sidebar-accent-foreground"
                  )}
                >
                  <a>
                    <item.icon className="h-5 w-5" />
                    <span className="group-data-[collapsible=icon]:hidden">{item.label}</span>
                  </a>
                </SidebarMenuButton>
              </Link>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-2 border-t">
        <SidebarMenuButton
            tooltip="Repositório de Exemplo (GitHub)"
            className="justify-start"
            onClick={handleGitHubClick}
        >
            <Github className="h-5 w-5" />
            <span className="group-data-[collapsible=icon]:hidden">Exemplo GitHub</span>
        </SidebarMenuButton>
      </SidebarFooter>
    </Sidebar>
  );
}
    
