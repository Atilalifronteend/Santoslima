"use client";

import { SidebarTrigger } from "@/components/ui/sidebar";
import Link from 'next/link';
import { LeafIcon } from "lucide-react"; // Using LeafIcon as a placeholder logo

export default function AppHeader() {
  return (
    <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-card px-4 md:px-8 shadow-sm">
      <div className="md:hidden">
        <SidebarTrigger />
      </div>
      <Link href="/" className="flex items-center gap-2 text-lg font-semibold md:text-base">
        <LeafIcon className="h-7 w-7 text-primary" />
        <h1 className="text-2xl font-headline font-bold text-foreground">Programar é Ganhar Dinheiro</h1>
      </Link>
      {/* Add other header elements like User Profile Dropdown here if needed */}
    </header>
  );
}
