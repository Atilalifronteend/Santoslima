"use client";

import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Check, Copy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from '@/hooks/use-toast';

interface CodeBlockProps {
  code: string;
  language?: string;
  className?: string;
}

export default function CodeBlock({ code, language = "plaintext", className }: CodeBlockProps) {
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();

  // Highlight.js can be added here for syntax highlighting if desired.
  // For now, basic pre/code styling.

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setIsCopied(true);
      toast({ title: "Copiado!", description: "Código copiado para a área de transferência." });
      setTimeout(() => setIsCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
      toast({ title: "Erro", description: "Falha ao copiar o código.", variant: "destructive" });
    }
  };
  
  // Ensure component only renders on client due to navigator.clipboard and setTimeout
  const [isClient, setIsClient] = useState(false);
  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className={cn("relative rounded-md border bg-muted p-4 font-code text-sm overflow-x-auto", className)}>
        <pre><code>{code}</code></pre>
      </div>
    );
  }

  return (
    <div className={cn("relative rounded-lg border bg-muted/50 p-4 font-code text-sm overflow-x-auto shadow-inner", className)}>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-2 h-7 w-7 text-muted-foreground hover:bg-muted hover:text-foreground"
        onClick={copyToClipboard}
        aria-label="Copiar código"
      >
        {isCopied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
      </Button>
      <pre><code className={`language-${language}`}>{code}</code></pre>
    </div>
  );
}
