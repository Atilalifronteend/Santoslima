"use client";

import { useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { generateCodeSnippet, type GenerateCodeSnippetInput, type GenerateCodeSnippetOutput } from "@/ai/flows/generate-code-snippet";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import CodeBlock from "@/components/shared/code-block";
import { Loader2, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  description: z.string().min(10, { message: "A descrição deve ter pelo menos 10 caracteres." }).max(500, { message: "A descrição não pode exceder 500 caracteres."}),
  language: z.enum(["HTML", "CSS", "JavaScript"], { required_error: "Por favor, selecione uma linguagem." }),
});

type FormData = z.infer<typeof formSchema>;

export default function AiCodeAssistant() {
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
      language: "HTML",
    },
  });

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    setIsLoading(true);
    setGeneratedCode(null);
    try {
      const input: GenerateCodeSnippetInput = {
        description: data.description,
        language: data.language,
      };
      const result: GenerateCodeSnippetOutput = await generateCodeSnippet(input);
      setGeneratedCode(result.codeSnippet);
      toast({
        title: "Código Gerado!",
        description: "Seu snippet de código está pronto.",
      });
    } catch (error) {
      console.error("Error generating code snippet:", error);
      toast({
        title: "Erro ao Gerar Código",
        description: "Houve um problema ao contatar a IA. Tente novamente mais tarde.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-semibold">Descreva o código que você precisa:</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="Ex: Um formulário de login com campos para email e senha, e um botão de submit."
                    className="min-h-[100px] resize-y"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="language"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="font-semibold">Linguagem:</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma linguagem" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="HTML">HTML</SelectItem>
                    <SelectItem value="CSS">CSS</SelectItem>
                    <SelectItem value="JavaScript">JavaScript</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <Button type="submit" disabled={isLoading} className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="mr-2 h-4 w-4" />
            )}
            Gerar Código
          </Button>
        </form>
      </Form>

      {isLoading && (
        <div className="text-center py-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="mt-2 text-muted-foreground">Gerando código, por favor aguarde...</p>
        </div>
      )}

      {generatedCode && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-2 font-headline">Código Gerado:</h3>
          <CodeBlock code={generatedCode} language={form.getValues("language").toLowerCase()} />
        </div>
      )}
    </div>
  );
}
